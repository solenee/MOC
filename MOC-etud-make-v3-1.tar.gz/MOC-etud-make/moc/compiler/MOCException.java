package moc.compiler;

public class MOCException extends Exception {
	private static final long serialVersionUID = 1L;

	public MOCException(String a) {
		super(a);
	}

}
