//--------------------------------------------------
// INFO la classe representant une info de TDS
//--------------------------------------------------
package moc.tds;

public interface INFO {



}
